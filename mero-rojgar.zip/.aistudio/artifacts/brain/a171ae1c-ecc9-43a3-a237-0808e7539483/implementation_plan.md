# Guest Preview Mode & Sign-Up Registration Flow

Adds a zero-credential **Guest Preview Mode** so users can immediately explore all workspaces inside **Mero Rojgar** without needing an ID or password, paired with a full bilingual **Sign-Up / Account Registration** form integrated into the Google Sign-In authentication flow.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Because this app enforces Google Sign-In via Jetpack Credential Manager and zero-trust Firestore security rules, hardcoded passwords and unauthenticated database writes are intentionally avoided. Your "all" selections are synthesized below into a secure, friction-free experience:

- **Immediate Access to See Inside (Guest Preview Mode + Auth Guidance)**: Adds a prominent **Explore Inside (Guest Preview)** button alongside **Sign in with Google**, plus a collapsible **Auth & Emulator Guide** explaining how Google Sign-In works (and how an administrator can optionally enable Email/Password in Firebase Console if desired later).
- **Sign-Up & Registration Flow**: Adds a **Sign In | Sign Up** segmented tab switcher on the Auth screen so new users can fill out their registration form before authenticating via **Create Account with Google**, plus a post-login onboarding prompt if a user signed in directly without completing registration.
- **Registration Fields**: Captures full name, account role (`Job Seeker`, `Employer`, `Sponsor`), Nepal district, professional headline, skills, expected NPR salary range, preferred language (`नेपाली` / `English`), and privacy/recruiter-discovery consents.
- **Full Preview Scope**: Guest Preview Mode unlocks read-only exploration across **all four role workspaces** (`Job Seeker` tabs including Home, JobFeed, Applications, Auto Apply, Gigs, Skill Passport, Rewards, Profile; plus `Employer`, `Sponsor`, and `Admin` previews).

---

## 1. Overview & Core Concept

- **What It Does**: Replaces the single-button sign-in gate with a two-tab **Welcome & Registration Portal** (`Sign In` and `Sign Up`) and a dedicated **Guest Preview** runtime shell populated with realistic in-memory Nepali workforce data.
- **Target Audience / Persona**: First-time evaluators on the streaming emulator who want to inspect every screen immediately, as well as new Nepali job seekers, employers, and sponsors registering tailored profiles.
- **Key Value**: Removes the friction of needing test credentials to inspect the app while preserving end-to-end Firebase security and giving new users a real multi-role onboarding registration form.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Explore Inside (Guest Preview Mode)**:
   - User launches the app on the Auth screen and taps **Explore Inside (Guest Preview)** (`गेस्ट पूर्वावलोकन`).
   - App enters an isolated, read-only preview workspace preloaded with rich Nepali jobs, gigs, sponsor campaigns, skill evidence, and sample resumes—never calling Firestore unauthenticated.
   - User can browse Home, JobFeed (search, filters, density toggle, compare, bookmarks in local preview state, empty-state illustrations), Gigs, Rewards, Profile, and switch across **Job Seeker**, **Employer**, **Sponsor**, and **Admin** roles via the top bar.
   - A compact **Preview Mode** banner at the top provides a one-tap **Sign In / Register** button, and attempting permanent cloud mutations prompts the user to sign in with Google to save changes.
2. **Pre-Auth Sign-Up Registration (`Sign Up` Tab)**:
   - User switches to the **Sign Up** tab on the Auth screen.
   - User enters Full Name, picks Role (`Job Seeker`, `Employer`, `Sponsor`), selects District, adds Headline & Skills (with quick skill chips), optionally adjusts Expected Salary (NPR), picks Language (`नेपाली` / `English`), and reviews privacy consents.
   - Client validates all field limits inline and highlights missing required inputs.
   - User taps **Register & Continue with Google**; upon Google Credential Manager completion, the registration draft is atomically persisted as their Firestore user profile (`users/{uid}`) and optional opt-in talent directory entry.
3. **Post-Login Onboarding Fallback**:
   - If a user signs in directly via the **Sign In** tab and has a fresh default profile, a concise dismissible **Complete Your Account Registration** card/sheet lets them customize role, district, skills, and consents at any time.

### Visual Identity & Theme

- **Aesthetic Direction**: Modern Himalayan Editorial Portal — retaining the signature Himalayan Navy (`#0F294A`) gradient header, emblem medallion, and high-contrast surface cards with crisp Material 3 segmented tabs (`Sign In` | `Sign Up`) and role selector chips.
- **Color Palette & Mood**: Uses `MeroRojgarTheme` tokens (`primary` Himalayan Navy / Sapphire, `secondary` Nepal Crimson for primary actions, `tertiary` Saffron Gold for preview & registration badges, and `errorContainer` for inline validation).
- **Typography & Hierarchy**: Bilingual `display`/`headline` titles paired with `titleMedium` section headers, clear `OutlinedTextField` labels, and `labelSmall` helper/validation captions.
- **Component Styling & Layout**: Scrollable `widthIn(max = 520.dp)` card layout on the Auth screen, responsive `NavigationBar` / `NavigationRail` inside Guest Preview matching the authenticated shell, and `48.dp` minimum touch targets on every chip, button, and checkbox.

### Interactive Feedback & Motion

- **Tab & Form Transitions**: Smooth `AnimatedContent` transition between **Sign In** and **Sign Up** panels plus expandable **Auth & Emulator Guide** accordion.
- **Inline Validation**: Immediate per-field helper messages and disabled-free helpful error banners if required registration details are invalid or Google Sign-In is cancelled.
- **Preview Action Guard**: Interactive controls inside Preview Mode show clear feedback banners when an action requires a real Google-authenticated cloud session.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: In-Memory Guest Preview Shell vs. Anonymous Auth or Hardcoded Demo Password**
  - *Chosen Approach*: Isolate Guest Preview into an in-memory preview shell powered by local sample datasets, keeping all Firestore repositories gated behind real Google Sign-In (`Firebase.auth.currentUser != null`).
  - *Why*: Anonymous and password fallbacks are prohibited on this backend, hardcoded demo credentials pose a security risk, and Firestore rules deny unauthenticated reads/writes. A pure in-memory preview shell guarantees zero permission errors and instant exploration across all roles.
  - *Alternatives Considered*: Email/password demo credentials in code—rejected due to security constraints and unprovisioned email/password auth.
- **Decision 2: Pre-Auth Registration Draft Persisted on Google Sign-In**
  - *Chosen Approach*: Hold the validated registration form as an in-memory `RegistrationDraft` state during auth and pass it into initial profile creation as soon as Google Sign-In returns a verified `uid`.
  - *Why*: Lets users experience a true Sign-Up registration form on the entry screen while ensuring every Firestore document is still created by an authenticated owner matching `request.auth.uid`.
  - *Alternatives Considered*: Requiring two separate steps after login only—less intuitive for users looking for a dedicated Sign-Up form right alongside Sign-In.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         AppContent (Root Router)                          │
│  State: firebaseUser (AuthStateListener), isGuestPreview, pendingDraft    │
└───────────┬───────────────────────────────┬───────────────────────────────┘
            │ user == null && !preview      │ user == null && preview
            ▼                               ▼
┌──────────────────────────────┐  ┌─────────────────────────────────────────┐
│ AuthScreen (Sign In/Sign Up) │  │ GuestPreviewShell (Zero-Firestore)      │
│ • Segmented Tab: Sign In     │  │ • In-memory fixtures for Jobs, Gigs,    │
│   - Google Sign-In Button    │  │   Campaigns, Profile, Resumes, Skills   │
│   - Explore Inside (Preview) │  │ • Full Role Switcher (Seeker, Employer, │
│   - Auth & Emulator Guide    │  │   Sponsor, Admin) + NE/EN Toggle        │
│ • Segmented Tab: Sign Up     │  │ • Top Preview Banner -> Sign In / Exit  │
│   - Validated Registration   │  └─────────────────────────────────────────┘
│     Draft -> Google Sign-In  │
└───────────┬──────────────────┘
            │ Firebase Auth succeeds (uid != null)
            ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                AuthenticatedShell (key(user.uid) Scoped)                  │
│  • Applies pending RegistrationDraft on first profile initialization      │
│  • Optional Post-Login Onboarding Sheet if registration skipped           │
│  • Full Firestore persistence + Firebase AI Logic features                │
└───────────────────────────────────────────────────────────────────────────┘
```

### Security & Input Validation Safeguards

- **Zero Hardcoded Credentials**: No static usernames, demo passwords, or `signInWithEmailAndPassword()` / `signInAnonymously()` calls appear anywhere in application source code.
- **Strict Auth Boundary**: Firestore listeners and mutations run exclusively inside `AuthenticatedShell` when `Firebase.auth.currentUser` is non-null; `GuestPreviewShell` never instantiates Firestore listeners or writes to cloud storage.
- **Rule-Aligned Registration Validation**: Every field in `RegistrationDraft` (name length `1..80`, district `<= 60`, headline `<= 120`, role allowlist, salary bounds `max >= min >= 0`, skill count `<= 30`) is sanitized and validated before being written to `users/{uid}` under owner-only security rules.

### Data Model & State

- **`RegistrationDraft`**: Lightweight immutable data class holding `displayName`, `activeRole`, `district`, `headline`, `skills`, `expectedSalaryMin`, `expectedSalaryMax`, `locale`, `consentsRecruiterDiscovery`, and `consentsRewardsTerms`.
- **`GuestPreviewState`**: In-memory UI state holder supporting interactive filtering, density toggle, compare tray, temporary bookmarks, role switching, and locale switching during preview without touching Firestore.

### Interactive Component & State Mapping

- **Auth Screen Mode Tabs (`Sign In` | `Sign Up`)**: Toggles between quick Google Sign-In + Preview entry and the validated account registration form.
- **Explore Inside Button**: Sets `isGuestPreview = true` in `AppContent` to mount `GuestPreviewShell` immediately.
- **Register & Continue with Google Button**: Validates all Sign-Up inputs, stores `pendingRegistrationDraft`, and invokes Credential Manager `onGoogleSignInClicked`; on success, `MainAppViewModel` initializes `users/{uid}` using the draft and clears it.
- **Preview Mode Top Banner ("Sign In")**: Resets `isGuestPreview = false` so the user lands cleanly on `AuthScreen` to sign in or complete registration with Google.
